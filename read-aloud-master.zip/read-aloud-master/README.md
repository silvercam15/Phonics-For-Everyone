# read-aloud
Text-to-speech that just works - a Chrome extension
